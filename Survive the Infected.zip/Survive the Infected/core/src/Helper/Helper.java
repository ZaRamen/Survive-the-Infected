package Helper;

public class Helper
{
    private static final float PPM = 64.0f;

    public static float getPPM()
    {
        return PPM;
    }
}
